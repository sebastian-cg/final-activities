package com.example.tab_experiment2;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.tab_experiment2.fragments.FragmentCooking;
import com.example.tab_experiment2.fragments.FragmentStories;
import com.example.tab_experiment2.fragments.FragmentTechNews;


public class MyViewPagerAdapter extends FragmentStateAdapter {
    public MyViewPagerAdapter(@NonNull MainActivity fragment) {
        super(fragment);
    }
    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new FragmentStories();
            case 1:
                return new FragmentTechNews();
            case 2:
                return new FragmentCooking();
            default:
                return new FragmentStories();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }

}
