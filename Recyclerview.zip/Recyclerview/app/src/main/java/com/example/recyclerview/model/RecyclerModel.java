package com.example.recyclerview.model;

public class RecyclerModel {
}
